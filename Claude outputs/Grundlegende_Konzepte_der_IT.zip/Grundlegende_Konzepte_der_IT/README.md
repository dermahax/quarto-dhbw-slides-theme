# Einführung in die Informationstechnik

Folien und Übungsblätter zur Lehreinheit „Grundlagen der IT“ im Modul
W3WI_104 (DHBW Lörrach, Wirtschaftsinformatik, 1. Studienjahr).

## Aufbau

```
_quarto.yml                 Projekt: Titel, Chevrons, Orga-Daten
00-orga.qmd                 Organisatorisches, Ablauf, Projektarbeit
01-einfuehrung.qmd          Warum IT? Hubble, Begriff Informatik, Geschichte
02-information.qmd          Analog/Digital, Bits, Zahlensysteme, Komplement, IEEE 754, Zeichensätze
03-logik-schaltungen.qmd    Aussagenlogik, Gatter, Transistor, Addierer, Flipflop
04-rechnerarchitektur.qmd   Komponenten, Von-Neumann, CPU, Interrupts, Speicher, Parallelität
05-algorithmen.qmd          Algorithmen, Robot Problem, Rekursion, Compiler, Sprachen, IDE, git
06-daten-ki.qmd             Daten, Big Data, neuronale Netze, KI, Projektpräsentationen
figures/NN-name/            Abbildungen (SVG) je Kapitel
Uebungen/                   Übungsblätter mit Lösungen (eigenes Quarto-Projekt, Typst → PDF)
_extensions/dermahax/       DHBW-Theme (Repo quarto-dhbw-slides, Version siehe _extension.yml)
```

## Bauen

Folien (im Projektordner):

```
quarto render                     alle Kapitel
quarto render 02-information.qmd  ein Kapitel
quarto preview 02-information.qmd beim Schreiben
```

Übungsblätter (im Ordner `Uebungen/`, eigenes Projekt):

```
cd Uebungen
quarto render                     alle Blätter und Lösungen als PDF
```

Die PDFs landen in `Uebungen/pdf/`. Für die Lösungsblätter ist in jeder
`*-loesung.qmd` nur der Kopf anders; die Aufgaben werden aus dem Aufgabenblatt
eingebunden (`{{< include >}}`), damit beide Dokumente nicht auseinanderlaufen.

## Theme aktualisieren

```
quarto update dermahax/quarto-dhbw-slides
```

## Quellen

Die Überschneidungen mit der Vorgänger-Vorlesung „Grundlagen der IT“ (Hubble-Einstieg,
Rechnerkomponenten, Von-Neumann/Harvard, Transistor, Analog/Digital, Compiler/Linker/Loader,
Editor vs. IDE, Daten/Big Data) orientieren sich inhaltlich an deren Folien;
Text und Abbildungen wurden neu erstellt. Literatur: Gumm/Sommer, *Einführung in die Informatik*;
Tanenbaum/Austin, *Rechnerarchitektur*; Patterson/Hennessy, *Rechnerorganisation und -entwurf*.
