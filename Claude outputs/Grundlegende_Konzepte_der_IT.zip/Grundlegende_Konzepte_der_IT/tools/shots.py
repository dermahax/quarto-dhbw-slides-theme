#!/usr/bin/env python3
"""Screenshots aller Folien einer gerenderten HTML-Datei als Kontaktbogen.
Aufruf: python tools/shots.py 01-einfuehrung.html [outdir]
"""
import asyncio, os, sys, math
from playwright.async_api import async_playwright
from PIL import Image

html = os.path.abspath(sys.argv[1])
outdir = sys.argv[2] if len(sys.argv) > 2 else "/tmp/claude-0/-home-claude/1a12726a-7f7c-510a-acf4-bf8e0f5a0fc9/scratchpad/shots"
os.makedirs(outdir, exist_ok=True)
base = os.path.splitext(os.path.basename(html))[0]


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch()
        pg = await b.new_page(viewport={"width": 1920, "height": 1080})
        await pg.goto("file://" + html + "?transition=none")
        await pg.wait_for_timeout(1500)
        n = await pg.evaluate("Reveal.getTotalSlides()")
        shots = []
        for i in range(n):
            await pg.evaluate(f"Reveal.slide({i}, 0, 999)")  # alle Fragmente zeigen
            await pg.wait_for_timeout(250)
            p = os.path.join(outdir, f"{base}-{i:02d}.png")
            await pg.screenshot(path=p)
            shots.append(p)
        await b.close()
    # Kontaktbogen: 3 Spalten
    thumbs = [Image.open(p).resize((640, 360)) for p in shots]
    cols = 3
    rows = math.ceil(len(thumbs) / cols)
    per_sheet = 12
    for s in range(0, len(thumbs), per_sheet):
        chunk = thumbs[s:s + per_sheet]
        r = math.ceil(len(chunk) / cols)
        sheet = Image.new("RGB", (cols * 650, r * 370), "white")
        for k, im in enumerate(chunk):
            sheet.paste(im, ((k % cols) * 650, (k // cols) * 370))
        sheet.save(os.path.join(outdir, f"{base}-sheet{s // per_sheet}.png"))
    print(n, "slides")

asyncio.run(main())
