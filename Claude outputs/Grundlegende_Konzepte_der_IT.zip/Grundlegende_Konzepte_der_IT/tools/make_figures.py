#!/usr/bin/env python3
"""Erzeugt alle SVG-Abbildungen der Vorlesung unter figures/NN-name/.

Aufruf im Projektordner:  python tools/make_figures.py
Reine Standardbibliothek + matplotlib (nur für die zwei Diagramme).
"""
import math
import os

RED = "#E0001A"
DARKRED = "#961620"
GRAY = "#58636C"
LGRAY = "#7F8A96"
LLGRAY = "#D9DEE3"
INK = "#1f2933"
BLUE = "#1f6feb"
GREEN = "#2e8b57"
FONT = "font-family='Segoe UI, Helvetica, Arial, sans-serif'"

ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figures")


class SVG:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.parts = []

    def add(self, s):
        self.parts.append(s)

    def rect(self, x, y, w, h, fill="white", stroke=GRAY, sw=2, rx=6, **kw):
        extra = " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in kw.items())
        self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>')

    def text(self, x, y, s, size=18, fill=INK, anchor="middle", weight="normal", **kw):
        size = round(size * 1.25, 1)
        extra = " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in kw.items())
        s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        font = "" if "font_family" in kw else FONT
        self.add(f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" font-weight="{weight}" {font} {extra}>{s}</text>')

    def line(self, x1, y1, x2, y2, stroke=GRAY, sw=2, arrow=False, dash=None):
        m = ' marker-end="url(#arr)"' if arrow else ""
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"{m}{d}/>')

    def path(self, d, stroke=GRAY, sw=2, fill="none", arrow=False, dash=None):
        m = ' marker-end="url(#arr)"' if arrow else ""
        dd = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<path d="{d}" stroke="{stroke}" stroke-width="{sw}" fill="{fill}"{m}{dd}/>')

    def circle(self, cx, cy, r, fill="white", stroke=GRAY, sw=2):
        self.add(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')

    def box(self, x, y, w, h, label, fill="white", stroke=GRAY, size=20, color=INK, weight="bold", sub=None, rx=8):
        self.rect(x, y, w, h, fill=fill, stroke=stroke, rx=rx)
        if sub:
            self.text(x + w / 2, y + h / 2 - 4, label, size=size, fill=color, weight=weight)
            self.text(x + w / 2, y + h / 2 + 20, sub, size=size - 4, fill=GRAY)
        else:
            self.text(x + w / 2, y + h / 2 + size * 0.35, label, size=size, fill=color, weight=weight)

    def save(self, name):
        head = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">'
                '<defs><marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,0 L10,5 L0,10 z" fill="{GRAY}"/></marker>'
                '<marker id="arrred" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,0 L10,5 L0,10 z" fill="{RED}"/></marker></defs>')
        path = os.path.join(ROOT, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(head + "\n".join(self.parts) + "</svg>")
        print("wrote", path)


# --------------------------------------------------------------------- 01
def hubble():
    s = SVG(980, 420)
    # Solarmodule
    for x in (60, 660):
        s.rect(x, 150, 180, 110, fill="#2f4f8f", stroke="#1e3560", rx=3)
        for i in range(1, 6):
            s.line(x + i * 30, 150, x + i * 30, 260, stroke="#5b7ec9", sw=1)
        for j in range(1, 4):
            s.line(x, 150 + j * 27, x + 180, 150 + j * 27, stroke="#5b7ec9", sw=1)
    s.line(240, 205, 300, 205, stroke=LGRAY, sw=6)
    s.line(600, 205, 660, 205, stroke=LGRAY, sw=6)
    # Körper
    s.rect(300, 130, 300, 150, fill="#cfd6dd", stroke=GRAY, rx=18)
    s.rect(300, 130, 90, 150, fill="#b8c1cb", stroke=GRAY, rx=18)
    s.text(470, 200, "Teleskop-", size=18, fill=GRAY, weight="bold")
    s.text(470, 224, "Röhre (Optik)", size=18, fill=GRAY, weight="bold")
    # Blendentür
    s.path("M600,135 L650,90 L655,100 L605,145 Z", fill="#e6eaee", stroke=GRAY)
    # Antennen
    s.line(430, 130, 430, 70, stroke=GRAY, sw=3)
    s.circle(430, 62, 12, fill="white")
    s.line(520, 280, 520, 340, stroke=GRAY, sw=3)
    s.circle(520, 348, 12, fill="white")
    # Labels
    def lab(x, y, tx, ty, t):
        s.line(x, y, tx, ty, stroke=RED, sw=1.5)
        s.text(tx, ty - 6, t, size=17, fill=RED, weight="bold")
    lab(150, 150, 240, 110, "Solarmodule (2 × 2,45 × 7,56 m, ≈ 2800 W)")
    lab(430, 60, 250, 60, "S-Band-Antenne (Funk zur Erde)")
    lab(520, 350, 520, 400, "Antenne 2 (Redundanz)")
    lab(640, 92, 760, 60, "Blendentür")
    lab(345, 280, 250, 330, "Bordcomputer, Datenrekorder,")
    s.text(250, 348, "Instrumente, Akkus (6 × NiH₂)", size=17, fill=RED, weight="bold")
    s.text(640, 25, "Hubble-Weltraumteleskop (schematisch)", size=20, fill=INK, weight="bold")
    s.save("01-einfuehrung/hubble.svg")


def timeline():
    events = [
        ("≈ 2500 v. Chr.", "Abakus"),
        ("1642", "Pascaline"),
        ("1837", "Babbage: Analytical Engine"),
        ("1941", "Zuse Z3"),
        ("1945/46", "ENIAC · Von-Neumann-Bericht"),
        ("1947", "Transistor"),
        ("1958", "Integrierter Schaltkreis"),
        ("1971", "Intel 4004 (Mikroprozessor)"),
        ("1981", "IBM PC"),
        ("1991", "WWW · Linux"),
        ("2007", "iPhone"),
        ("2022", "ChatGPT"),
    ]
    s = SVG(1800, 280)
    y = 150
    s.line(40, y, 1770, y, stroke=GRAY, sw=4, arrow=True)
    n = len(events)
    for i, (d, t) in enumerate(events):
        x = 110 + i * (1580 / (n - 1))
        s.circle(x, y, 9, fill=RED, stroke=RED)
        up = i % 2 == 0
        ty = y - 55 if up else y + 60
        s.line(x, y, x, ty + (10 if up else -26), stroke=LGRAY, sw=1.5)
        s.text(x, ty, d, size=18, fill=RED, weight="bold")
        s.text(x, ty + (28 if up else 30), t, size=17, fill=INK)
    s.save("01-einfuehrung/timeline.svg")


def moore():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    data = [(1971, 2.3e3, "4004"), (1978, 2.9e4, "8086"), (1985, 2.75e5, "386"), (1993, 3.1e6, "Pentium"),
            (2000, 4.2e7, "Pentium 4"), (2006, 2.9e8, "Core 2"), (2012, 1.4e9, "Ivy Bridge"),
            (2018, 6.9e9, "Apple A12"), (2023, 1.9e10, "Apple M2 Max")]
    xs = [d[0] for d in data]
    ys = [d[1] for d in data]
    plt.rcParams.update({"font.size": 13})
    fig, ax = plt.subplots(figsize=(9, 4.6), dpi=100)
    ax.plot(xs, ys, color=RED, linewidth=2, marker="o", markersize=6)
    for x, y, t in data:
        ax.annotate(t, (x, y), textcoords="offset points", xytext=(6, -14), fontsize=11, color=GRAY)
    yy = [2.3e3 * 2 ** ((x - 1971) / 2) for x in range(1971, 2024)]
    ax.plot(range(1971, 2024), yy, color=LGRAY, linewidth=1.5, linestyle="--", label="Verdopplung alle 2 Jahre")
    ax.set_yscale("log")
    ax.set_ylabel("Transistoren pro Chip")
    ax.set_xlabel("Jahr")
    ax.grid(True, which="major", color=LLGRAY, linewidth=0.8)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    ax.spines["left"].set_color(LGRAY)
    ax.spines["bottom"].set_color(LGRAY)
    ax.legend(frameon=False, loc="upper left")
    fig.tight_layout()
    out = os.path.join(ROOT, "01-einfuehrung", "moore.svg")
    fig.savefig(out, format="svg")
    print("wrote", out)


# --------------------------------------------------------------------- 02
def sampling():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    t = np.linspace(0, 2, 400)
    sig = np.sin(2 * np.pi * 1.1 * t) + 0.4 * np.sin(2 * np.pi * 3.3 * t + 1)
    plt.rcParams.update({"font.size": 13})
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), dpi=100, sharey=True)
    titles = ["Analoges Signal", "Abtastung (zeitdiskret)", "Abtastung + Quantisierung (digital)"]
    ts = np.arange(0, 2.001, 0.1)
    ss = np.sin(2 * np.pi * 1.1 * ts) + 0.4 * np.sin(2 * np.pi * 3.3 * ts + 1)
    levels = np.linspace(-1.5, 1.5, 7)
    q = levels[np.abs(ss[:, None] - levels[None, :]).argmin(axis=1)]
    for ax, title in zip(axes, titles):
        ax.plot(t, sig, color=LGRAY, linewidth=1.5)
        ax.set_title(title, fontsize=15, color=INK)
        ax.set_xlabel("Zeit")
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
        ax.grid(True, color=LLGRAY, linewidth=0.8)
    axes[0].plot(t, sig, color=RED, linewidth=2)
    axes[1].stem(ts, ss, linefmt=RED, markerfmt="o", basefmt=" ")
    for lv in levels:
        axes[2].axhline(lv, color=LLGRAY, linewidth=0.8, linestyle=":")
    axes[2].step(ts, q, where="post", color=RED, linewidth=2)
    axes[2].plot(ts, q, "o", color=RED, markersize=4)
    axes[0].set_ylabel("Wert")
    fig.tight_layout()
    out = os.path.join(ROOT, "02-information", "sampling.svg")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    fig.savefig(out, format="svg")
    print("wrote", out)


def ieee754():
    s = SVG(1000, 190)
    x = 20
    fields = [("Vorzeichen", 1, "#fde2e4", RED), ("Exponent", 8, "#e4ecf7", BLUE), ("Mantisse (23 Bit)", 23, "#e6f3ea", GREEN)]
    total = 32
    width = 960
    for name, bits, fill, col in fields:
        w = width * bits / total
        s.rect(x, 50, w, 70, fill=fill, stroke=col, rx=4)
        s.text(x + w / 2, 95, name if bits > 1 else "S", size=20, fill=col, weight="bold")
        s.text(x + w / 2, 40, f"{bits} Bit", size=16, fill=GRAY)
        x += w
    # Beispiel 0.15625 = 0 01111100 01000000000000000000000
    bits = "0" + "01111100" + "01000000000000000000000"
    x = 20
    for i, b in enumerate(bits):
        w = width / total
        s.text(x + w / 2, 150, b, size=17, fill=INK, font_family="Consolas, monospace")
        x += w
    s.text(500, 180, "Beispiel: 0,15625 = 1,01₂ · 2⁻³   →   Exponent 124 = 127 (Bias) − 3", size=17, fill=GRAY)
    s.save("02-information/ieee754.svg")


# --------------------------------------------------------------------- 03
def switch_circuit(name, kind):
    s = SVG(760, 280)
    # Batterie links
    s.line(60, 80, 60, 180, stroke=GRAY, sw=3)
    s.line(45, 120, 75, 120, stroke=INK, sw=4)
    s.line(52, 135, 68, 135, stroke=INK, sw=2)
    s.text(60, 200, "Batterie", size=16, fill=GRAY)
    s.line(60, 80, 200, 80, stroke=GRAY, sw=3)
    s.line(60, 180, 640, 180, stroke=GRAY, sw=3)
    # Lampe rechts
    s.circle(640, 130, 26, fill="#fff6cc", stroke=GRAY)
    s.line(622, 112, 658, 148, stroke=GRAY, sw=2)
    s.line(658, 112, 622, 148, stroke=GRAY, sw=2)
    s.line(640, 80, 640, 104, stroke=GRAY, sw=3)
    s.line(640, 156, 640, 180, stroke=GRAY, sw=3)
    s.text(680, 136, "Lampe", size=16, fill=GRAY, anchor="start")

    def switch(x, y, label):
        s.circle(x, y, 5, fill=GRAY)
        s.circle(x + 80, y, 5, fill=GRAY)
        s.line(x, y, x + 70, y - 28, stroke=RED, sw=3)
        s.text(x + 40, y - 40, label, size=18, fill=RED, weight="bold")

    if kind == "and":
        s.line(200, 80, 240, 80, stroke=GRAY, sw=3)
        switch(240, 80, "Schalter A")
        s.line(320, 80, 400, 80, stroke=GRAY, sw=3)
        switch(400, 80, "Schalter B")
        s.line(480, 80, 640, 80, stroke=GRAY, sw=3)
        s.text(380, 255, "Reihenschaltung: Lampe leuchtet nur, wenn A UND B geschlossen sind", size=18, fill=INK)
    else:
        s.line(200, 80, 260, 80, stroke=GRAY, sw=3)
        s.line(260, 80, 260, 130, stroke=GRAY, sw=3)
        s.line(260, 80, 300, 80, stroke=GRAY, sw=3)
        switch(300, 80, "Schalter A")
        s.line(380, 80, 640, 80, stroke=GRAY, sw=3)
        s.line(260, 130, 300, 130, stroke=GRAY, sw=3)
        s.circle(300, 130, 5, fill=GRAY); s.circle(380, 130, 5, fill=GRAY)
        s.line(300, 130, 370, 102, stroke=RED, sw=3)
        s.text(340, 165, "Schalter B", size=18, fill=RED, weight="bold")
        s.line(380, 130, 440, 130, stroke=GRAY, sw=3)
        s.line(440, 130, 440, 80, stroke=GRAY, sw=3)
        s.text(380, 255, "Parallelschaltung: Lampe leuchtet, wenn A ODER B geschlossen ist", size=18, fill=INK)
    s.save(f"03-logik/{name}.svg")


def gate_and(s, x, y, w=90, h=60, label=""):
    s.path(f"M{x},{y} L{x + w * 0.5},{y} A{h / 2},{h / 2} 0 0 1 {x + w * 0.5},{y + h} L{x},{y + h} Z", stroke=INK, sw=2.5, fill="white")
    if label:
        s.text(x + w * 0.4, y + h / 2 + 7, label, size=18, fill=INK, weight="bold")


def gate_or(s, x, y, w=90, h=60, label=""):
    s.path(f"M{x},{y} Q{x + w * 0.35},{y + h / 2} {x},{y + h} Q{x + w * 0.6},{y + h} {x + w},{y + h / 2} Q{x + w * 0.6},{y} {x},{y} Z", stroke=INK, sw=2.5, fill="white")
    if label:
        s.text(x + w * 0.45, y + h / 2 + 7, label, size=18, fill=INK, weight="bold")


def gate_not(s, x, y, w=70, h=60):
    s.path(f"M{x},{y} L{x + w - 10},{y + h / 2} L{x},{y + h} Z", stroke=INK, sw=2.5, fill="white")
    s.circle(x + w - 4, y + h / 2, 6, fill="white", stroke=INK, sw=2.5)


def gates():
    s = SVG(1100, 330)
    names = ["AND", "OR", "NOT", "NAND", "XOR"]
    x0 = 40
    for i, n in enumerate(names):
        x = x0 + i * 215
        y = 60
        if n == "AND":
            gate_and(s, x, y)
            out = x + 90
        elif n == "OR":
            gate_or(s, x, y)
            out = x + 90
        elif n == "NOT":
            gate_not(s, x, y)
            out = x + 72
        elif n == "NAND":
            gate_and(s, x, y)
            s.circle(x + 96, y + 30, 6, fill="white", stroke=INK, sw=2.5)
            out = x + 102
        else:
            s.path(f"M{x - 12},{y} Q{x + 20},{y + 30} {x - 12},{y + 60}", stroke=INK, sw=2.5)
            gate_or(s, x, y)
            out = x + 90
        # inputs
        if n == "NOT":
            s.line(x - 40, y + 30, x, y + 30, stroke=INK, sw=2.5)
            s.text(x - 50, y + 36, "a", size=18)
        else:
            s.line(x - 40, y + 15, x, y + 15, stroke=INK, sw=2.5)
            s.line(x - 40, y + 45, x, y + 45, stroke=INK, sw=2.5)
            s.text(x - 50, y + 21, "a", size=18)
            s.text(x - 50, y + 51, "b", size=18)
        s.line(out, y + 30, out + 40, y + 30, stroke=INK, sw=2.5)
        s.text(x + 45, 30, n, size=22, fill=RED, weight="bold")
        # truth table
        rows = {"AND": ["0 0 | 0", "0 1 | 0", "1 0 | 0", "1 1 | 1"],
                "OR": ["0 0 | 0", "0 1 | 1", "1 0 | 1", "1 1 | 1"],
                "NOT": ["0 | 1", "1 | 0"],
                "NAND": ["0 0 | 1", "0 1 | 1", "1 0 | 1", "1 1 | 0"],
                "XOR": ["0 0 | 0", "0 1 | 1", "1 0 | 1", "1 1 | 0"]}[n]
        hdr = "a | y" if n == "NOT" else "a b | y"
        s.text(x + 45, 165, hdr, size=17, fill=GRAY, weight="bold", font_family="Consolas, monospace")
        for j, r in enumerate(rows):
            s.text(x + 45, 192 + j * 26, r, size=17, fill=INK, font_family="Consolas, monospace")
        sym = {"AND": "y = a ∧ b", "OR": "y = a ∨ b", "NOT": "y = ¬a", "NAND": "y = ¬(a ∧ b)", "XOR": "y = a ⊕ b"}[n]
        s.text(x + 45, 315, sym, size=17, fill=GRAY)
    s.save("03-logik/gates.svg")


def transistor():
    s = SVG(920, 300)
    # Symbol
    cx, cy = 200, 150
    s.circle(cx, cy, 60, fill="white", stroke=INK, sw=2.5)
    s.line(cx - 20, cy - 35, cx - 20, cy + 35, stroke=INK, sw=5)
    s.line(cx - 90, cy, cx - 20, cy, stroke=INK, sw=2.5)
    s.line(cx - 20, cy - 15, cx + 30, cy - 50, stroke=INK, sw=2.5)
    s.line(cx - 20, cy + 15, cx + 30, cy + 50, stroke=INK, sw=2.5)
    s.line(cx + 30, cy - 50, cx + 30, cy - 100, stroke=INK, sw=2.5)
    s.line(cx + 30, cy + 50, cx + 30, cy + 100, stroke=INK, sw=2.5)
    s.path(f"M{cx + 30},{cy + 50} l-16,-4 l4,-12 z", fill=INK, stroke=INK)
    s.text(cx - 100, cy - 10, "Basis (B)", size=18, fill=RED, weight="bold", anchor="end")
    s.text(cx + 45, cy - 80, "Kollektor (C)", size=18, fill=RED, weight="bold", anchor="start")
    s.text(cx + 45, cy + 90, "Emitter (E)", size=18, fill=RED, weight="bold", anchor="start")
    # Erklärung rechts als Wasserhahn-Analogie
    s.text(640, 60, "Steuerbarer Schalter", size=22, fill=INK, weight="bold")
    s.text(640, 100, "kleine Spannung an B (> 0,7 V)", size=18, fill=GRAY)
    s.text(640, 126, "→ Strom fließt C → E   („1“)", size=18, fill=INK)
    s.text(640, 170, "keine Spannung an B", size=18, fill=GRAY)
    s.text(640, 196, "→ kein Strom   („0“)", size=18, fill=INK)
    s.text(640, 250, "Transfer + Resistor = steuerbarer Widerstand", size=17, fill=LGRAY)
    s.save("03-logik/transistor.svg")


def halfadder():
    s = SVG(760, 300)
    # inputs
    s.text(40, 96, "a", size=22, weight="bold")
    s.text(40, 176, "b", size=22, weight="bold")
    s.line(60, 90, 160, 90, stroke=INK, sw=2.5)
    s.line(60, 170, 200, 170, stroke=INK, sw=2.5)
    # XOR at top
    s.path("M288,60 Q320,90 288,120", stroke=INK, sw=2.5)
    gate_or(s, 300, 60, label="=1")
    s.line(300, 75, 300, 90, stroke=INK, sw=0)  # no-op
    # connect a,b to xor: need the lines to reach gate inputs (300,75) and (300,105)
    s.line(160, 90, 160, 75, stroke=INK, sw=2.5)
    s.line(160, 75, 300, 75, stroke=INK, sw=2.5)
    s.line(200, 170, 200, 105, stroke=INK, sw=2.5)
    s.line(200, 105, 300, 105, stroke=INK, sw=2.5)
    s.circle(160, 90, 5, fill=INK, stroke=INK)
    s.circle(200, 170, 5, fill=INK, stroke=INK)
    # AND at bottom
    gate_and(s, 300, 190, label="&")
    s.line(160, 90, 160, 205, stroke=INK, sw=2.5)
    s.line(160, 205, 300, 205, stroke=INK, sw=2.5)
    s.line(200, 170, 200, 235, stroke=INK, sw=2.5)
    s.line(200, 235, 300, 235, stroke=INK, sw=2.5)
    # outputs
    s.line(390, 90, 480, 90, stroke=INK, sw=2.5, arrow=True)
    s.line(390, 220, 480, 220, stroke=INK, sw=2.5, arrow=True)
    s.text(500, 96, "s = a ⊕ b   (Summe)", size=20, anchor="start", fill=RED, weight="bold")
    s.text(500, 226, "c = a ∧ b   (Übertrag)", size=20, anchor="start", fill=RED, weight="bold")
    s.text(380, 285, "Halbaddierer: addiert zwei Bits", size=18, fill=GRAY)
    s.save("03-logik/halfadder.svg")


def fulladder():
    s = SVG(960, 320)
    def ha(x, y, label):
        s.rect(x, y, 150, 100, fill="#f3f5f7", stroke=GRAY)
        s.text(x + 75, y + 44, "Halb-", size=18, weight="bold")
        s.text(x + 75, y + 68, "addierer", size=18, weight="bold")
        s.text(x + 75, y - 8, label, size=15, fill=GRAY)
        s.text(x + 138, y + 32, "s", size=14, fill=GRAY)
        s.text(x + 138, y + 82, "c", size=14, fill=GRAY)
    ha(200, 50, "HA 1")
    ha(500, 110, "HA 2")
    s.text(60, 86, "a", size=22, weight="bold"); s.line(80, 80, 200, 80, stroke=INK, sw=2.5)
    s.text(60, 126, "b", size=22, weight="bold"); s.line(80, 120, 200, 120, stroke=INK, sw=2.5)
    s.text(60, 186, "cᵢₙ", size=22, weight="bold"); s.line(90, 180, 500, 180, stroke=INK, sw=2.5)
    # s1 -> HA2 input
    s.line(350, 80, 420, 80, stroke=INK, sw=2.5); s.line(420, 80, 420, 140, stroke=INK, sw=2.5); s.line(420, 140, 500, 140, stroke=INK, sw=2.5)
    s.text(385, 72, "s₁", size=15, fill=GRAY)
    # c1 -> OR
    s.line(350, 130, 390, 130, stroke=INK, sw=2.5); s.line(390, 130, 390, 265, stroke=INK, sw=2.5); s.line(390, 265, 700, 265, stroke=INK, sw=2.5)
    s.text(370, 122, "c₁", size=15, fill=GRAY)
    # HA2 s -> out
    s.line(650, 140, 860, 140, stroke=INK, sw=2.5, arrow=True)
    s.text(870, 146, "s", size=22, anchor="start", fill=RED, weight="bold")
    # HA2 c -> OR
    s.line(650, 190, 680, 190, stroke=INK, sw=2.5); s.line(680, 190, 680, 235, stroke=INK, sw=2.5); s.line(680, 235, 700, 235, stroke=INK, sw=2.5)
    s.text(665, 182, "c₂", size=15, fill=GRAY)
    gate_or(s, 700, 220, label="≥1")
    s.line(790, 250, 860, 250, stroke=INK, sw=2.5, arrow=True)
    s.text(870, 256, "cₒᵤₜ", size=22, anchor="start", fill=RED, weight="bold")
    s.text(480, 305, "Volladdierer = 2 Halbaddierer + OR: addiert a, b und den Übertrag cᵢₙ", size=17, fill=GRAY)
    s.save("03-logik/fulladder.svg")


def srlatch():
    s = SVG(760, 300)
    def nor(x, y):
        gate_or(s, x, y, label="≥1")
        s.circle(x + 96, y + 30, 6, fill="white", stroke=INK, sw=2.5)
    nor(260, 50); nor(260, 190)
    s.text(60, 71, "S (set)", size=20, weight="bold", anchor="start"); s.line(150, 65, 260, 65, stroke=INK, sw=2.5)
    s.text(60, 241, "R (reset)", size=20, weight="bold", anchor="start"); s.line(160, 235, 260, 235, stroke=INK, sw=2.5)
    s.line(362, 80, 480, 80, stroke=INK, sw=2.5, arrow=True); s.text(500, 86, "Q̄", size=22, anchor="start", fill=RED, weight="bold")
    s.line(362, 220, 480, 220, stroke=INK, sw=2.5, arrow=True); s.text(500, 226, "Q", size=22, anchor="start", fill=RED, weight="bold")
    # Rückkopplung
    s.line(420, 80, 420, 140, stroke=RED, sw=2.5); s.line(420, 140, 230, 160, stroke=RED, sw=0)
    s.path("M420,140 L230,140 L230,205 L260,205", stroke=RED, sw=2.5)
    s.line(420, 220, 420, 160, stroke=RED, sw=2.5)
    s.path("M420,160 L240,160 L240,95 L260,95", stroke=RED, sw=2.5)
    s.text(600, 150, "Rückkopplung", size=18, fill=RED)
    s.text(600, 175, "= Gedächtnis", size=18, fill=RED)
    s.text(380, 290, "RS-Flipflop aus zwei NOR-Gattern: speichert 1 Bit", size=18, fill=GRAY)
    s.save("03-logik/srlatch.svg")


# --------------------------------------------------------------------- 04
def vonneumann():
    s = SVG(1000, 430)
    s.rect(60, 40, 400, 240, fill="#fbe9eb", stroke=RED, rx=12)
    s.text(260, 70, "Zentraleinheit (CPU)", size=22, fill=RED, weight="bold")
    s.box(90, 100, 160, 150, "Steuerwerk", fill="white", sub="Befehlszähler,")
    s.text(170, 215, "Befehlsregister", size=16, fill=GRAY)
    s.box(270, 100, 160, 150, "Rechenwerk", fill="white", sub="ALU, Register")
    s.line(250, 175, 270, 175, stroke=GRAY, sw=2, arrow=True)
    s.box(560, 60, 380, 200, "Hauptspeicher", fill="#eef2f6", sub="Befehle UND Daten")
    s.text(750, 210, "adressierbare Zellen 0 … n−1", size=16, fill=GRAY)
    s.box(560, 320, 380, 80, "Ein-/Ausgabe (E/A)", fill="white", sub="Tastatur, Bildschirm, Platte, Netz")
    # Bus
    s.rect(60, 320, 400, 80, fill="#e4ecf7", stroke=BLUE, rx=8)
    s.text(260, 352, "Bus-System", size=22, fill=BLUE, weight="bold")
    s.text(260, 380, "Adress-, Daten-, Steuerbus", size=16, fill=GRAY)
    s.line(260, 280, 260, 320, stroke=BLUE, sw=4, arrow=True); s.line(260, 320, 260, 280, stroke=BLUE, sw=4, arrow=True)
    s.line(460, 360, 560, 360, stroke=BLUE, sw=4, arrow=True); s.line(560, 360, 460, 360, stroke=BLUE, sw=4, arrow=True)
    s.path("M460,340 L520,340 L520,260 L560,260", stroke=BLUE, sw=4, arrow=True)
    s.path("M560,240 L520,240 L520,340", stroke=BLUE, sw=0)
    s.text(500, 420, "Von-Neumann-Architektur: ein gemeinsamer Speicher für Programm und Daten, ein Bus", size=18, fill=GRAY)
    s.save("04-architektur/vonneumann.svg")


def harvard():
    s = SVG(1000, 330)
    s.rect(330, 60, 340, 200, fill="#fbe9eb", stroke=RED, rx=12)
    s.text(500, 95, "CPU", size=22, fill=RED, weight="bold")
    s.box(360, 120, 130, 110, "Steuerwerk", fill="white", size=18)
    s.box(510, 120, 130, 110, "Rechenwerk", fill="white", size=18)
    s.box(40, 100, 230, 120, "Programm-", fill="#eef2f6", sub="speicher (Befehle)")
    s.box(730, 100, 230, 120, "Daten-", fill="#eef2f6", sub="speicher")
    s.line(270, 160, 330, 160, stroke=BLUE, sw=4, arrow=True); s.line(330, 160, 270, 160, stroke=BLUE, sw=4, arrow=True)
    s.line(670, 160, 730, 160, stroke=BLUE, sw=4, arrow=True); s.line(730, 160, 670, 160, stroke=BLUE, sw=4, arrow=True)
    s.text(300, 140, "Bus 1", size=15, fill=BLUE)
    s.text(700, 140, "Bus 2", size=15, fill=BLUE)
    s.text(500, 305, "Harvard-Architektur: getrennte Speicher und Busse für Befehle und Daten", size=18, fill=GRAY)
    s.save("04-architektur/harvard.svg")


def fde():
    s = SVG(1150, 360)
    cx, cy, r = 300, 180, 120
    steps = [("Fetch", "Befehl aus Speicher holen", -90), ("Decode", "Befehl entschlüsseln", 30), ("Execute", "Befehl ausführen", 150)]
    for name, desc, ang in steps:
        a = math.radians(ang)
        x, y = cx + r * math.cos(a), cy + r * math.sin(a)
        s.circle(x, y, 52, fill="#fbe9eb", stroke=RED, sw=2.5)
        s.text(x, y + 7, name, size=20, fill=RED, weight="bold")
    # arrows along circle
    for start in (-40, 80, 200):
        a1, a2 = math.radians(start), math.radians(start + 50)
        x1, y1 = cx + r * math.cos(a1), cy + r * math.sin(a1)
        x2, y2 = cx + r * math.cos(a2), cy + r * math.sin(a2)
        s.path(f"M{x1},{y1} A{r},{r} 0 0 1 {x2},{y2}", stroke=GRAY, sw=3, arrow=True)
    s.text(620, 90, "1. Fetch", size=20, fill=RED, weight="bold", anchor="start")
    s.text(620, 116, "Befehl von der Adresse im Befehlszähler laden,", size=17, anchor="start")
    s.text(620, 138, "Befehlszähler erhöhen", size=17, anchor="start")
    s.text(620, 185, "2. Decode", size=20, fill=RED, weight="bold", anchor="start")
    s.text(620, 211, "Steuerwerk erkennt Operation und Operanden", size=17, anchor="start")
    s.text(620, 258, "3. Execute", size=20, fill=RED, weight="bold", anchor="start")
    s.text(620, 284, "ALU rechnet / Speicher lesen oder schreiben /", size=17, anchor="start")
    s.text(620, 306, "Sprung: Befehlszähler neu setzen", size=17, anchor="start")
    s.text(300, 345, "… Milliarden Mal pro Sekunde (Takt)", size=17, fill=GRAY)
    s.save("04-architektur/fde.svg")


def memhier():
    s = SVG(1000, 420)
    levels = [("Register", "< 1 ns", "Bytes", "#fbe9eb"), ("L1-Cache", "≈ 1 ns", "KB", "#fbe9eb"), ("L2/L3-Cache", "≈ 3–20 ns", "MB", "#f7eef0"),
              ("Hauptspeicher (RAM)", "≈ 80 ns", "GB", "#eef2f6"), ("SSD", "≈ 50 µs", "TB", "#eef2f6"), ("Festplatte / Netz / Cloud", "≈ 5 ms", "PB", "#e8ecf0")]
    top, bottom = 40, 380
    n = len(levels)
    hh = (bottom - top) / n
    for i, (name, t, size, fill) in enumerate(levels):
        y = top + i * hh
        w_top = 160 + i * 110
        w_bot = 160 + (i + 1) * 110
        x1, x2 = 500 - w_top / 2, 500 + w_top / 2
        x3, x4 = 500 + w_bot / 2, 500 - w_bot / 2
        s.path(f"M{x1},{y} L{x2},{y} L{x3},{y + hh} L{x4},{y + hh} Z", fill=fill, stroke=GRAY, sw=1.5)
        s.text(500, y + hh / 2 + 7, name, size=19, weight="bold")
        s.text(930, y + hh / 2 + 7, t, size=17, fill=RED, anchor="end")
        s.text(70, y + hh / 2 + 7, size, size=17, fill=GRAY, anchor="start")
    s.text(70, 28, "Kapazität", size=16, fill=GRAY, anchor="start")
    s.text(930, 28, "Zugriffszeit", size=16, fill=RED, anchor="end")
    s.line(30, 60, 30, 370, stroke=LGRAY, sw=2, arrow=True); s.text(30, 395, "größer", size=14, fill=GRAY)
    s.line(970, 370, 970, 60, stroke=LGRAY, sw=2, arrow=True); s.text(940, 395, "schneller, teurer", size=14, fill=GRAY, anchor="end")
    s.save("04-architektur/memhier.svg")


def interrupt():
    s = SVG(1000, 330)
    # Polling
    s.text(20, 40, "Polling", size=20, fill=RED, weight="bold", anchor="start")
    s.line(120, 70, 960, 70, stroke=LGRAY, sw=2)
    for i in range(10):
        x = 130 + i * 85
        s.rect(x, 55, 30, 30, fill="#fde2e4", stroke=RED, rx=3, sw=1.5)
        s.rect(x + 34, 55, 46, 30, fill="#eef2f6", stroke=GRAY, rx=3, sw=1.5)
    s.text(145, 110, "„Ist was da?“", size=14, fill=RED)
    s.text(260, 110, "Arbeit", size=14, fill=GRAY)
    s.text(540, 140, "CPU fragt ständig nach – verschwendet Zeit, reagiert trotzdem verzögert", size=17, fill=GRAY)
    # Interrupt
    s.text(20, 200, "Interrupt", size=20, fill=RED, weight="bold", anchor="start")
    s.line(120, 230, 960, 230, stroke=LGRAY, sw=2)
    s.rect(130, 215, 400, 30, fill="#eef2f6", stroke=GRAY, rx=3, sw=1.5)
    s.text(330, 236, "Programm läuft", size=15, fill=GRAY)
    s.rect(530, 215, 110, 30, fill="#fde2e4", stroke=RED, rx=3, sw=1.5)
    s.text(585, 236, "Handler", size=15, fill=RED)
    s.rect(640, 215, 310, 30, fill="#eef2f6", stroke=GRAY, rx=3, sw=1.5)
    s.text(795, 236, "Programm läuft weiter", size=15, fill=GRAY)
    s.line(530, 180, 530, 213, stroke=RED, sw=3, arrow=True)
    s.text(530, 172, "Taste gedrückt! (IRQ)", size=15, fill=RED)
    s.text(540, 300, "Gerät meldet sich selbst – CPU unterbricht, behandelt, kehrt zurück", size=17, fill=GRAY)
    s.save("04-architektur/interrupt.svg")


def pipeline():
    s = SVG(1000, 330)
    stages = ["F", "D", "E", "M", "W"]
    cols = ["#fde2e4", "#fdebd0", "#e6f3ea", "#e4ecf7", "#ede4f7"]
    s.text(20, 40, "Ohne Pipeline: ein Befehl nach dem anderen", size=19, weight="bold", anchor="start")
    for i in range(2):
        for j, st in enumerate(stages):
            x = 60 + (i * 5 + j) * 50
            s.rect(x, 55, 46, 34, fill=cols[j], stroke=GRAY, rx=3, sw=1.2)
            s.text(x + 23, 78, st, size=16)
    s.text(590, 78, "→ 10 Takte für 2 Befehle", size=17, fill=GRAY, anchor="start")
    s.text(20, 140, "Mit Pipeline: Stufen überlappen (wie am Fließband)", size=19, weight="bold", anchor="start")
    for i in range(4):
        s.text(45, 178 + i * 40, f"B{i + 1}", size=15, fill=GRAY, anchor="end")
        for j, st in enumerate(stages):
            x = 60 + (i + j) * 50
            s.rect(x, 158 + i * 40, 46, 34, fill=cols[j], stroke=GRAY, rx=3, sw=1.2)
            s.text(x + 23, 181 + i * 40, st, size=16)
    s.text(590, 200, "→ 8 Takte für 4 Befehle", size=17, fill=GRAY, anchor="start")
    s.text(590, 230, "F Fetch · D Decode · E Execute", size=15, fill=GRAY, anchor="start")
    s.text(590, 254, "M Memory · W Write-back", size=15, fill=GRAY, anchor="start")
    s.save("04-architektur/pipeline.svg")


def components():
    s = SVG(1000, 460)
    s.rect(40, 40, 920, 380, fill="#f3f5f7", stroke=GRAY, rx=14)
    s.text(500, 70, "Mainboard (Hauptplatine)", size=22, fill=GRAY, weight="bold")
    s.box(90, 110, 220, 140, "CPU", fill="#fbe9eb", stroke=RED, sub="Prozessor + Kühler")
    s.box(360, 110, 150, 140, "RAM", fill="#eef2f6", sub="Arbeitsspeicher")
    s.box(560, 110, 170, 140, "Chipsatz", fill="white", sub="verbindet alles")
    s.box(780, 110, 150, 140, "Grafik", fill="#e6f3ea", stroke=GREEN, sub="GPU (+ VRAM)")
    s.box(90, 290, 220, 100, "SSD / HDD", fill="white", sub="Massenspeicher")
    s.box(360, 290, 150, 100, "Netzteil", fill="white", sub="Strom")
    s.box(560, 290, 170, 100, "Netzwerk", fill="white", sub="LAN / WLAN")
    s.box(780, 290, 150, 100, "Anschlüsse", fill="white", sub="USB, HDMI, …")
    s.line(200, 250, 200, 290, stroke=BLUE, sw=3)
    s.line(310, 180, 360, 180, stroke=BLUE, sw=3)
    s.line(510, 180, 560, 180, stroke=BLUE, sw=3)
    s.line(730, 180, 780, 180, stroke=BLUE, sw=3)
    s.line(645, 250, 645, 290, stroke=BLUE, sw=3)
    s.line(855, 250, 855, 290, stroke=BLUE, sw=3)
    s.line(435, 250, 435, 290, stroke=LGRAY, sw=2, dash="6,4")
    s.save("04-architektur/components.svg")


# --------------------------------------------------------------------- 05
def robot_grid():
    s = SVG(620, 460)
    n = 6
    cell = 60
    ox, oy = 40, 40
    walls = {(2, 1), (2, 2), (2, 3), (4, 3), (4, 4), (4, 5)}
    for r in range(n):
        for c in range(n):
            fill = GRAY if (c, r) in walls else "white"
            s.rect(ox + c * cell, oy + r * cell, cell, cell, fill=fill, stroke=LGRAY, sw=1.5, rx=0)
    # Roboter
    rx, ry = ox + 0 * cell + 30, oy + 5 * cell + 30
    s.circle(rx, ry, 20, fill=RED, stroke=RED)
    s.path(f"M{rx},{ry - 12} L{rx + 10},{ry + 6} L{rx - 10},{ry + 6} Z", fill="white", stroke="white")
    # Ziel
    gx, gy = ox + 5 * cell + 30, oy + 0 * cell + 30
    s.rect(gx - 20, gy - 20, 40, 40, fill="#e6f3ea", stroke=GREEN, rx=6)
    s.text(gx, gy + 7, "Ziel", size=16, fill=GREEN, weight="bold")
    s.text(310, 425, "Befehle: vor() · links() · rechts() · wandVorne()", size=17, fill=GRAY)
    s.text(310, 448, "Start unten links (Blick nach oben), Ziel oben rechts", size=15, fill=LGRAY)
    s.save("05-algorithmen/robot.svg")


def recursion_tree():
    s = SVG(1000, 380)
    def node(x, y, t, hl=False):
        s.rect(x - 38, y - 18, 76, 36, fill="#fbe9eb" if hl else "white", stroke=RED if hl else GRAY, rx=8)
        s.text(x, y + 7, t, size=17, weight="bold", fill=RED if hl else INK)
    tree = {("fib(5)", 500, 40): [("fib(4)", 300, 120), ("fib(3)", 700, 120)],
            ("fib(4)", 300, 120): [("fib(3)", 180, 200), ("fib(2)", 420, 200)],
            ("fib(3)", 700, 120): [("fib(2)", 620, 200), ("fib(1)", 780, 200)],
            ("fib(3)", 180, 200): [("fib(2)", 110, 280), ("fib(1)", 250, 280)],
            ("fib(2)", 420, 200): [("fib(1)", 370, 280), ("fib(0)", 470, 280)],
            ("fib(2)", 620, 200): [("fib(1)", 570, 280), ("fib(0)", 670, 280)],
            ("fib(2)", 110, 280): [("fib(1)", 70, 350), ("fib(0)", 150, 350)]}
    for (t, x, y), kids in tree.items():
        for (kt, kx, ky) in kids:
            s.line(x, y + 18, kx, ky - 18, stroke=LGRAY, sw=1.5)
    drawn = set()
    for (t, x, y), kids in tree.items():
        node(x, y, t, hl=(t == "fib(3)"))
        drawn.add((x, y))
        for (kt, kx, ky) in kids:
            if (kx, ky) not in drawn:
                node(kx, ky, kt, hl=(kt == "fib(3)"))
                drawn.add((kx, ky))
    s.text(870, 320, "fib(3) wird", size=16, fill=RED)
    s.text(870, 342, "2× berechnet,", size=16, fill=RED)
    s.text(870, 364, "fib(2) 3×", size=16, fill=RED)
    s.save("05-algorithmen/fibtree.svg")


def hanoi():
    s = SVG(900, 260)
    for i, name in enumerate(["A (Start)", "B (Hilfe)", "C (Ziel)"]):
        x = 150 + i * 300
        s.line(x - 120, 200, x + 120, 200, stroke=GRAY, sw=6)
        s.line(x, 60, x, 200, stroke=GRAY, sw=6)
        s.text(x, 240, name, size=18, fill=GRAY)
    widths = [200, 160, 120, 80]
    for j, w in enumerate(widths):
        s.rect(150 - w / 2, 172 - j * 28, w, 24, fill="#fbe9eb" if j % 2 else "#eef2f6", stroke=RED if j % 2 else GRAY, rx=6)
    s.path("M280,120 Q450,20 720,120", stroke=RED, sw=2.5, arrow=True, dash="8,6")
    s.text(450, 45, "alle Scheiben nach C – nie größere auf kleinere", size=17, fill=RED)
    s.save("05-algorithmen/hanoi.svg")


def compile_pipeline():
    s = SVG(1150, 260)
    items = [("Quelltext", "main.c / .java", "#eef2f6"), ("Compiler", "übersetzt", "#fbe9eb"), ("Objektcode", "main.o", "#eef2f6"),
             ("Linker", "bindet Bibliotheken", "#fbe9eb"), ("Programm", "main.exe", "#eef2f6"), ("Loader", "lädt in RAM", "#fbe9eb"), ("Prozess", "läuft auf CPU", "#e6f3ea")]
    x = 20
    for i, (a, b, f) in enumerate(items):
        s.box(x, 70, 140, 90, a, fill=f, sub=b, size=19, stroke=RED if f == "#fbe9eb" else GRAY)
        if i < len(items) - 1:
            s.line(x + 140, 115, x + 165, 115, stroke=GRAY, sw=2.5, arrow=True)
        x += 165
    s.text(575, 215, "Interpreter (Python, JavaScript): liest den Quelltext Zeile für Zeile und führt ihn direkt aus – kein eigener Übersetzungsschritt", size=16, fill=GRAY)
    s.save("05-algorithmen/compile.svg")


def git_graph():
    s = SVG(1100, 300)
    main_y, feat_y = 110, 210
    def c(x, y, label, msg):
        s.circle(x, y, 16, fill="#fbe9eb", stroke=RED, sw=2.5)
        s.text(x, y - 28, label, size=15, fill=GRAY, font_family="Consolas, monospace")
        s.text(x, y + 42, msg, size=15, fill=INK)
    s.line(100, main_y, 900, main_y, stroke=GRAY, sw=3)
    s.path(f"M300,{main_y} Q340,{feat_y} 400,{feat_y} L600,{feat_y} Q680,{feat_y} 720,{main_y}", stroke=BLUE, sw=3)
    c(140, main_y, "a1f3", "init")
    c(300, main_y, "b7c2", "README")
    c(520, main_y, "c9d0", "Folien Kap. 1")
    c(720, main_y, "e4f1", "Merge")
    c(860, main_y, "f0a9", "Abgabe")
    c(420, feat_y, "d2e5", "Diagramm")
    c(600, feat_y, "d8b3", "Zusammenfassung")
    s.text(60, main_y + 6, "main", size=17, fill=RED, weight="bold", anchor="end")
    s.text(330, feat_y + 6, "feature", size=17, fill=BLUE, weight="bold", anchor="end")
    s.text(550, 285, "Commit = Schnappschuss + Nachricht + Autor + Zeit · Branch = eigene Arbeitslinie · Merge führt zusammen", size=15, fill=GRAY)
    s.save("05-algorithmen/git.svg")


def binsearch():
    s = SVG(1000, 250)
    arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]
    for i, v in enumerate(arr):
        x = 60 + i * 88
        hl = i == 6
        s.rect(x, 60, 80, 60, fill="#fbe9eb" if hl else "white", stroke=RED if hl else GRAY, rx=6)
        s.text(x + 40, 98, str(v), size=22, weight="bold", fill=RED if hl else INK)
        s.text(x + 40, 145, str(i), size=15, fill=GRAY)
    s.text(500, 40, "Gesucht: 38", size=20, fill=RED, weight="bold")
    s.path("M100,190 L900,190", stroke=LGRAY, sw=2)
    s.text(500, 180, "1. Mitte (Index 4): 16 < 38 → rechts weiter      2. Mitte (Index 7): 56 > 38 → links weiter", size=16, fill=INK)
    s.text(500, 215, "3. Mitte (Index 5): 23 < 38 → rechts weiter      4. Index 6: 38 gefunden ✓  (4 statt bis zu 10 Vergleiche)", size=16, fill=INK)
    s.save("05-algorithmen/binsearch.svg")


# --------------------------------------------------------------------- 06
def dikw():
    s = SVG(1150, 340)
    levels = [("Wissen", "„Bei Hitze mehr Eis einkaufen“", "#fbe9eb"), ("Information", "„32 °C = heißester Tag des Jahres“", "#f7eef0"),
              ("Daten", "„32“, „2026-07-14“, „°C“", "#eef2f6"), ("Zeichen", "3, 2, °, C", "#e8ecf0")]
    for i, (name, ex, fill) in enumerate(levels):
        y = 40 + i * 70
        wt, wb = 120 + i * 140, 120 + (i + 1) * 140
        s.path(f"M{380 - wt / 2},{y} L{380 + wt / 2},{y} L{380 + wb / 2},{y + 66} L{380 - wb / 2},{y + 66} Z", fill=fill, stroke=GRAY, sw=1.5)
        s.text(380, y + 42, name, size=20, weight="bold")
        s.text(740, y + 42, ex, size=16, fill=GRAY, anchor="start")
    s.text(380, 330, "Kontext, Regeln und Erfahrung machen aus Zeichen Wissen", size=16, fill=LGRAY)
    s.save("06-daten-ki/dikw.svg")


def perceptron():
    s = SVG(1120, 340)
    ins = [("x₁", 60), ("x₂", 160), ("x₃", 260)]
    for name, y in ins:
        s.circle(120, y, 28, fill="#eef2f6", stroke=GRAY)
        s.text(120, y + 7, name, size=20, weight="bold")
    s.circle(480, 160, 60, fill="#fbe9eb", stroke=RED, sw=2.5)
    s.text(480, 150, "Σ wᵢxᵢ + b", size=19, fill=RED, weight="bold")
    s.text(480, 178, "Aktivierung", size=15, fill=GRAY)
    for (name, y), w in zip(ins, ["w₁", "w₂", "w₃"]):
        s.line(148, y, 425, 160 - (160 - y) * 0.35, stroke=GRAY, sw=2, arrow=True)
        s.text(290, (y + 160) / 2 - 8, w, size=17, fill=BLUE, weight="bold")
    s.line(540, 160, 700, 160, stroke=GRAY, sw=2.5, arrow=True)
    s.circle(740, 160, 30, fill="#e6f3ea", stroke=GREEN, sw=2.5)
    s.text(740, 167, "y", size=22, fill=GREEN, weight="bold")
    s.text(800, 120, "y = 1, wenn Summe > Schwelle", size=17, anchor="start")
    s.text(800, 148, "sonst y = 0", size=17, anchor="start")
    s.text(800, 200, "Gewichte wᵢ werden", size=17, fill=BLUE, anchor="start")
    s.text(800, 226, "beim Training gelernt", size=17, fill=BLUE, anchor="start")
    s.text(480, 300, "Perzeptron – ein künstliches Neuron (Rosenblatt, 1958)", size=17, fill=GRAY)
    s.save("06-daten-ki/perceptron.svg")


def nn():
    s = SVG(1000, 400)
    layers = [(4, 120, "Eingabe"), (5, 380, "Verdeckte Schicht 1"), (5, 620, "Verdeckte Schicht 2"), (2, 880, "Ausgabe")]
    pos = []
    for n, x, name in layers:
        ys = [200 + (i - (n - 1) / 2) * 60 for i in range(n)]
        pos.append([(x, y) for y in ys])
        s.text(x, 370, name, size=17, fill=GRAY)
    for a, b in zip(pos, pos[1:]):
        for (x1, y1) in a:
            for (x2, y2) in b:
                s.line(x1, y1, x2, y2, stroke=LLGRAY, sw=1)
    for li, layer in enumerate(pos):
        for (x, y) in layer:
            fill = "#eef2f6" if li == 0 else ("#e6f3ea" if li == len(pos) - 1 else "#fbe9eb")
            stroke = GRAY if li == 0 else (GREEN if li == len(pos) - 1 else RED)
            s.circle(x, y, 20, fill=fill, stroke=stroke, sw=2)
    s.text(120, 30, "Pixel, Merkmale …", size=15, fill=GRAY)
    s.text(880, 30, "„Katze“ / „Hund“", size=15, fill=GRAY)
    s.save("06-daten-ki/nn.svg")


def analytics():
    s = SVG(1000, 330)
    steps = [("Descriptive", "Was ist passiert?", "Umsatz Q4?"), ("Diagnostic", "Warum?", "Warum Rückgang?"),
             ("Predictive", "Was wird passieren?", "Ausfall der Pumpe?"), ("Prescriptive", "Was sollen wir tun?", "Welche Option?")]
    for i, (a, b, c) in enumerate(steps):
        x, y = 40 + i * 240, 220 - i * 50
        s.rect(x, y, 210, 90 + i * 50, fill="#fbe9eb" if i == 3 else "#eef2f6", stroke=RED if i == 3 else GRAY, rx=8)
        s.text(x + 105, y + 32, a, size=20, weight="bold", fill=RED if i == 3 else INK)
        s.text(x + 105, y + 58, b, size=16, fill=GRAY)
        s.text(x + 105, y + 82, c, size=15, fill=LGRAY)
    s.line(60, 40, 900, 40, stroke=LGRAY, sw=2, arrow=True)
    s.text(480, 28, "Wert und Schwierigkeit steigen", size=16, fill=GRAY)
    s.save("06-daten-ki/analytics.svg")


def scaling():
    s = SVG(1000, 320)
    s.text(250, 40, "Vertikal (scale up)", size=20, fill=RED, weight="bold")
    s.rect(180, 80, 140, 100, fill="#eef2f6", stroke=GRAY)
    s.text(250, 135, "Server", size=18, weight="bold")
    s.line(330, 130, 380, 130, stroke=GRAY, sw=2.5, arrow=True)
    s.rect(390, 60, 200, 160, fill="#fbe9eb", stroke=RED)
    s.text(490, 130, "größerer", size=18, weight="bold")
    s.text(490, 156, "Server", size=18, weight="bold")
    s.text(250, 270, "mehr CPU, RAM – einfach, aber begrenzt", size=16, fill=GRAY)
    s.text(750, 40, "Horizontal (scale out)", size=20, fill=RED, weight="bold")
    for i in range(4):
        s.rect(640 + i * 75, 100, 65, 80, fill="#eef2f6" if i == 0 else "#fbe9eb", stroke=GRAY if i == 0 else RED)
        s.text(672 + i * 75, 146, "S", size=18, weight="bold")
    s.text(790, 270, "mehr Knoten – Software muss verteilen können", size=16, fill=GRAY)
    s.save("06-daten-ki/scaling.svg")


if __name__ == "__main__":
    hubble(); timeline(); moore()
    sampling(); ieee754()
    switch_circuit("switch-and", "and"); switch_circuit("switch-or", "or"); gates(); transistor(); halfadder(); fulladder(); srlatch()
    vonneumann(); harvard(); fde(); memhier(); interrupt(); pipeline(); components()
    robot_grid(); recursion_tree(); hanoi(); compile_pipeline(); git_graph(); binsearch()
    dikw(); perceptron(); nn(); analytics(); scaling()
